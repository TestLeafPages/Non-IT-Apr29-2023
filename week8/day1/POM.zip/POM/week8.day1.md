
Todays Agenda!!
================
    09:00 - 10:00--> Exception Handling
	 10:00 - 10:20--> Explicit wait
	 10:20 - 10:35--> Break
	 10:35 - 11:15--> Extend Report
	 11:15 - 11:35--> Beakout + Break
	 11:35 - 12:30--> Integration with POM
	 12:30 - 01:15--> FrameWork 


Exception Handling
=====================

Abnormal behaviour which disrupts the program execution

Error- we cannot handle in programmatically

Exception-we can handle it programmatically to continue our execution



Wait
=======
java-Thread.sleep
selenium-implicit-findelement and findelements
Explicity - based on condition for single line of 










<dependency>
			<groupId>com.aventstack</groupId>
			<artifactId>extentreports</artifactId>
			<version>3.1.5</version>
		</dependency>
		
	
	
Extent Report
==========
-->Thrid Party API /framework from a avenstack(class)
-->To get the report with 
summary, 
graphs ,
scrennshots
we can have category,author,...

ExtentHtmlreporter
ExtentReports
attach reporter
ExtentTest
mediaenititybuilder

Steps:
======
1.Setup Physical report path
2.Create object for extentreports
3.Attach data with phusical file
4.Create a testcase and assigned test details
5.Steps level status
6.Mandatory step to stop.





To integrate the ExtentReport with POM
======================================
Step:1
------
Pre-Condition :
 
 1.Create a method in base class as startReport
    Copy and paste first 3 steps of ExtentReport
	and annonate with @BeforeSuite

@BeforeSuite -->start the report

@BeforeTest-->attaching the testdata(excel sheet)
@BeforeClass
@DataProvider-->fetch the data from readexcel file
@BeforeMethod -->precondition for every @Test Method
  @Test
  @Test
   
2.Create a method endReport in base class and annotate the method with @AfterSuite
  flush();
  
3.Create a method as testDetails and annotate the method with @BeforeClass
  add createTest(), assignAuthor(),assignCategory()

4.In @BeforeTest , assign the test deatails  as testname, testdesc , author, category 
and declare the variables as global in base class

5.Create a method as reportStep to get the status of the each method of the testcase
and call the method in pages in try catch block to get the status of the method

6.Add Screenshot 
create  a method as takeSnap with return type int
 include the snap shot code append with random number 

7.Call the takeSnap method in MediaEntityBuilderClass path

tep1:setup the report file to capture the status
step2:setup thedetails foe a single testcase
     testcase name
     testcase description
     testcase category
     testcase author
step3:Capture the status for each step


Integrate extent Report 
-------------------------
steps:
1.Create startReport()with @BeforeSuite in ProjecctSpecificMethod and Keep all the common code
2.Make ExtentReport as Global variable
3.create stopReport() @AfterSuite to have extent.flush().
4.Create testdetail()with @beforeClass for test case detail code
5.Declare ExtentTest Globally.
6.Create Global variable testname,testDescription,test author,and test category
7.Replace the hard code values with respective variable name
8.Assign the value for the variable in the setup() in the testcase

@BeforeSuite-----to start the report
  @BeforeTest----setting up the values for testcase name,des,aut,category
    @Beforeclass---set up the values in the report
      @DataProvider(2 set )
       @beforeMethod
                @Test


1.Create reportStep() with 2 args(stepDesc,status)
2.Add conditional statement to call pass()/fail() based on the status
3.In the step level method ,surround the selenium code with try catch block
4.call reportStep() from try and catch blolck with pass and fail status

Steps to attach Screenshot:
------------------------------
1.Create takeSnap()with selenium code to take the screen shot

2.Generating the random number and append the file name with random number
3.Have to return with random number
4.call the takesnap() from snapshot and get a random number to append with filename



https://robotframework.org/robotframework/
