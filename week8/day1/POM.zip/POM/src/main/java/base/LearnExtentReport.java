package base;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) throws IOException {

		/*step1:setup the report file to capture the status
		step2:setup thedetails foe a single testcase
		     testcase name
		     testcase description
		     testcase category
		     testcase author
		step3:Capture the status for each step
		
Steps:
======
1.Setup Physical report path                   -ExtentHtmlReporter
2.Create object for extentreports              -ExtentReports
3.Attach data with physical file               -attachreporter
4.Create a testcase and assigned test details  -ExtentTest
5.Steps level status
6.Mandatory step to stop.
		
*/
		
		//step1-setup physical report path
		
		ExtentHtmlReporter repo=new ExtentHtmlReporter("./reports/result.html");
		
		//retain prev data result
		repo.setAppendExisting(true);
		
		//step-2 create object for extentreporters
		
		ExtentReports extent=new ExtentReports();
		
		//step-3 atach data with physical file
		extent.attachReporter(repo);
		
		//step4- create a testcase and assigned test details
		
		ExtentTest test=extent.createTest("Login", "leaftaps application checking login data");
		test.assignAuthor("Dilip");
		test.assignCategory("smoke");
		
		//step-5 status of steps
		test.pass("enter the username",
				MediaEntityBuilder.createScreenCaptureFromPath(".././snap/img101558.png").build());
		test.fail("enter the password");
		test.fail("click on login");
		
		//step6-close report
		extent.flush();
		System.out.println("done");
	}

}
