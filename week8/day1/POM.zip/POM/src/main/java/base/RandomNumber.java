package base;

public class RandomNumber {

	public static void main(String[] args) {
		
		int random =(int)(Math.random()*999999);
		System.out.println(random);
		
//629743.5827692447,993765.7285278216,510786.45196514734
		//74708.7431669691
		//663322,13921
	}

}
