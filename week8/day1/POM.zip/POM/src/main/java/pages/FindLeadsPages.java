package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClassPOM;



public class FindLeadsPages extends BaseClassPOM{

	public FindLeadsPages(ChromeDriver driver) {
		this.driver=driver;
	}


}
