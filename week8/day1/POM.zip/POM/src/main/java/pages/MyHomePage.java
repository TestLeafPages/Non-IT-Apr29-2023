package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClassPOM;



public class MyHomePage extends BaseClassPOM{

	public MyHomePage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	
	public MyLeads clickOnLeads() {
		driver.findElement(By.linkText("Leads")).click();
		return new MyLeads(driver);
	}
}
