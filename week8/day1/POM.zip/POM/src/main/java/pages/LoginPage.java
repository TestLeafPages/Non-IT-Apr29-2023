package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

import base.BaseClassPOM;



public class LoginPage extends BaseClassPOM{

	
	public LoginPage(ChromeDriver driver,ExtentTest node) {
		this.driver=driver;
		this.node=node;
		
	}
	
	
	public LoginPage enterUserName(String username) throws IOException {
		
			try {
				driver.findElement(By.id("username")).sendKeys(username);
				reportStep("username enter successful","pass");
			} catch (Exception e) {
				reportStep("username is not  enter successful","fail");

			}

		
		
		return this;
		
	}
	
	public LoginPage enterPassword(String password) throws IOException {
		
			try {
				driver.findElement(By.id("password")).sendKeys(password);
				reportStep("password enter successful","pass");
			} catch (Exception e) {
				reportStep("password is not  enter successful","fail");

			}
			
		return this;
	}
	
	
	public HomePage clickOnLogin() throws IOException {
			try {
				driver.findElement(By.className("decorativeSubmit")).click();
				reportStep("login is  successful","pass");

			} catch (Exception e) {
				reportStep("login is not  successful","fail");

			}
			

		
		//m2
		return new HomePage(driver);
		
	}
}
