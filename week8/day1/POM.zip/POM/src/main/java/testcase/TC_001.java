package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClassPOM;
import pages.LoginPage;

public class TC_001 extends BaseClassPOM{

	@BeforeTest
	public void setup() {
		fileName="LoginData";
		testName="Login";
		testDesc="leaftaps application";
		testAuthor="Dilip";
		testCategory="smoke";
		
	}
	
	
	
	@Test(dataProvider  ="getData")
	public void loginData(String username,String pasword) throws IOException {
		
		System.out.println(driver);
		LoginPage lp=new LoginPage(driver,node);
		
		lp.enterUserName(username).enterPassword(pasword).clickOnLogin();
		
	}
	
}
