package exceptionhandling;

public class LearnThrows {

	public static void main(String[] args) throws InterruptedException {
		
Thread.sleep(2000);


	}

}
