package exceptionhandling;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login {

	public static void main(String[] args) {
		ChromeDriver driver=new ChromeDriver();


		driver.manage().window().maximize();

 
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("http://leaftaps.com/opentaps/control/main");

		try {
			driver.findElement(By.id("Username")).sendKeys("demosalesManager");
		} catch (Exception e) {
			System.out.println(e);
			driver.findElement(By.id("username")).sendKeys("DemoCsr");

		}


	}

}
