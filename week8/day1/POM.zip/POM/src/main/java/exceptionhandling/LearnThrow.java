package exceptionhandling;

public class LearnThrow {

	public static void main(String[] args) {
		
		int a=5;
		
		if(a<0) {
			System.out.println("negative number");
		}else {
			throw new ArithmeticException("positive number");
		}
	}

}
