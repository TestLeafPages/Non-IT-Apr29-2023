package exceptionhandling;


public class LearnException {

	public static void main(String[] args) {
		int a=10;
		int b=0;
		//10/0
		
		int[] num= {2,4,6,7,9};
		try {
			
			System.out.println(num[5]);
			
			System.out.println(a/b);
			
			
			
		} catch (ArithmeticException e) {

           System.out.println(a/1);
		}
	 catch(Exception e) {
			System.out.println(e);
			
			System.out.println(num[4]);
		}
		finally {
			System.out.println("finally block");
		}
		
		System.out.println("done");

	}

}
