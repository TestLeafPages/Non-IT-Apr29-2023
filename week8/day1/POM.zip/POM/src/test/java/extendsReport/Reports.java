package extendsReport;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class Reports {

	public static void main(String[] args) {

		//step1
		ExtentHtmlReporter repo= new ExtentHtmlReporter("./reports/result.html");

		repo.setAppendExisting(true);
		//step2
		ExtentReports extent= new ExtentReports();
		
		//step3
		extent.attachReporter(repo);
		
		//step4
		ExtentTest test= extent.createTest("createLead","details");
		
		test.assignAuthor("Dilip");
		test.assignCategory("smoke");
		//step5
		test.pass("username");
		test.pass("password");
		//step6
		extent.flush();
		System.out.println("done");


		
	}

}
